import { BaseModel } from "./base.model";

export interface Post extends BaseModel {
  postId: string;
  content: string;
  createdAt: Date;
  engagement: {
    likes: number;
    comments: number;
    shares: number;
  };
}

export interface CreatePostInput {
  userId: string;
  content: string;
  topicId?: string;
  hashtags?: string[];
}
